// Nhận dữ liệu từ zalo-main.js + đọc danh bạ / nhóm Zalo Web lưu trong máy, chuẩn hóa và gửi về CRM (qua bg.js).
(() => {
  const RAW = new Map(), USERS = {}, GROUPS = {}, SENT_NAMES = {}, SEEN = new Set(); let self = null, busy = false, lastNames = 0;
  chrome.storage.local.get(['zself'], s => { if (s.zself && !self) self = s.zself; });
  const setSelf = u => { u = String(u || ''); if (!u || u === '0' || u === self) return; self = u; chrome.storage.local.set({zself: u}); };
  const str = v => (v == null ? '' : typeof v === 'string' ? v : '');
  const addUser = (id, name, avatar) => { id = String(id || ''); if (!id || !name) return; const o = USERS[id] || (USERS[id] = {}); if (!o.name || o.name === id) o.name = String(name).slice(0, 120); if (avatar && !o.avatar) o.avatar = String(avatar); };
  const addGroup = (id, name, avatar) => { id = String(id || ''); if (!id || !name) return; const o = GROUPS[id] || (GROUPS[id] = {}); o.name = String(name).slice(0, 120); if (avatar) o.avatar = String(avatar); };
  const TYPE = [[/undo/, 'undo', 'Đã thu hồi một tin nhắn'], [/photo|gif|image/, 'photo'], [/sticker/, 'sticker'], [/voice/, 'voice'], [/video/, 'video'], [/share\.file|file/, 'file'],
    [/recommend|link/, 'link'], [/location/, 'text', '📍 Đã chia sẻ vị trí'], [/poll/, 'text', '📊 Bình chọn'], [/todo/, 'text', '✅ Giao việc'], [/ecard/, 'text', '🎉 Thiệp']];
  const norm = m => {
    const meById = self && String(m.uidFrom) === self, me = String(m.uidFrom) === '0' || meById;
    const to = String(m.idTo), from = String(m.uidFrom);
    const isGroup = !!m.__g || !!GROUPS[to] || (!!self && !me && to !== '0' && to !== self);
    const thread = me ? to : (isGroup ? to : from);
    const t = String(m.msgType || ''), c = m.content; let type = 'text', text = '', url = '', file = '', styles = '';
    if (typeof c === 'string') text = c; else if (c && typeof c === 'object') { text = str(c.title) || str(c.description) || str(c.msg) || ''; url = str(c.href) || str(c.thumb) || ''; }
    const k = TYPE.find(x => x[0].test(t));
    if (k) { type = k[1]; if (k[2]) { text = k[2] + (type === 'text' && str(c && c.title) ? ': ' + str(c.title) : ''); url = ''; } }
    else if (t !== 'webchat' && t) { if (!text || /^[A-Za-z_.]+$/.test(text)) text = '💬 Tin nhắn đặc biệt'; }
    if (type === 'sticker') { url = ''; text = ''; }
    if (type === 'file') { file = text || 'Tệp'; text = ''; }
    if (type === 'link') { type = 'text'; if (url && text.indexOf(url) < 0) text = (text ? text + '\n' : '') + url; url = ''; }
    if (type === 'photo' && text === url) text = '';
    try { for (const kk of ['textProperties', 'propertyExt']) { let v = m[kk] || (c && c[kk]); if (typeof v === 'string') v = JSON.parse(v); if (v && v.textProperties) v = typeof v.textProperties === 'string' ? JSON.parse(v.textProperties) : v.textProperties; if (v && Array.isArray(v.styles)) styles = JSON.stringify(v.styles.map(s => ({start: s.start, len: s.len, st: s.st}))); } } catch (e) {}
    if (!me && m.dName) addUser(from, m.dName);
    const fromName = me ? 'Tôi' : (str(m.dName) || (USERS[from] && USERS[from].name) || '');
    return {thread, isGroup, id: String(m.msgId), ts: Number(m.ts) || Date.now(), me, fromName, type, text: text.slice(0, 5000), url: url.slice(0, 1000), file, styles};
  };
  const isMsg = o => o && o.msgId != null && o.uidFrom != null && o.ts != null && o.msgType != null;
  const take = (o, g) => {
    if (!o || typeof o !== 'object') return;
    if (isMsg(o)) { const c = Object.assign({}, o); if (g) c.__g = 1; RAW.set(String(o.msgId), c); return; }
    if (o.zpw_enk && o.uid) setSelf(o.uid);
    if (o.userId && (o.displayName || o.zaloName)) addUser(o.userId, o.displayName || o.zaloName, o.avatar);
    if (o.groupId && o.name) addGroup(o.groupId, o.name, o.fullAvt || o.avt);
  };
  const walk = (o, d, g, n) => { if (!o || typeof o !== 'object' || d > 6 || n.c++ > 6000) return;
    if (Array.isArray(o)) { for (let i = 0; i < o.length && i < 3000; i++) walk(o[i], d + 1, g, n); return; }
    take(o, g); if (isMsg(o)) return;
    for (const key in o) { const v = o[key]; if (!v || typeof v !== 'object') continue;
      if (/gridInfoMap|groupInfo/i.test(key) && !Array.isArray(v)) for (const gid in v) { const x = v[gid]; if (x && x.name) addGroup(x.groupId || gid, x.name, x.fullAvt || x.avt); }
      if (/profiles?$/i.test(key) && !Array.isArray(v)) for (const uid in v) { const x = v[uid]; if (x && (x.displayName || x.zaloName)) addUser(x.userId || uid, x.displayName || x.zaloName, x.avatar); }
      walk(v, d + 1, g || /group/i.test(key), n); } };
  window.addEventListener('message', e => {
    const d = e.data; if (e.source !== window || !d || d.src !== 'skt-zmain' || !d.data) return; const x = d.data;
    if (x.self && x.self.uid) setSelf(x.self.uid);
    (x.users || []).forEach(u => addUser(u.id, u.name, u.avatar)); (x.groups || []).forEach(g => addGroup(g.id, g.name, g.avatar));
    (x.msgs || []).forEach(m => { if (isMsg(m)) RAW.set(String(m.msgId), m); });
  });
  // Đọc danh bạ, nhóm (và tin gần đây) Zalo Web đã lưu trong máy (IndexedDB) – chỉ đọc.
  async function scanIDB() {
    if (!indexedDB.databases) return;
    let dbs = []; try { dbs = await indexedDB.databases(); } catch (e) { return; }
    for (const info of dbs) {
      if (!info.name) continue;
      const db = await new Promise(r => { const q = indexedDB.open(info.name); q.onsuccess = () => r(q.result); q.onerror = () => r(null); q.onupgradeneeded = () => { try { q.transaction.abort(); } catch (e) {} r(null); }; });
      if (!db) continue;
      for (const st of Array.from(db.objectStoreNames)) {
        await new Promise(res => { try {
          const tx = db.transaction(st, 'readonly'), cur = tx.objectStore(st).openCursor(null, 'prev'); let n = 0; const ctr = {c: 0};
          cur.onsuccess = () => { const c = cur.result; if (!c || n++ > 2500) return res(); try { ctr.c = 0; walk(c.value, 0, /group/i.test(st), ctr); } catch (e) {} c.continue(); };
          cur.onerror = () => res(); tx.onabort = () => res();
        } catch (e) { res(); } });
      }
      db.close();
    }
  }
  // Lấy tên hiển thị trên danh sách hội thoại cho các hội thoại chưa rõ tên.
  function scanDOM(ids) {
    ids.slice(0, 60).forEach(id => { try {
      const el = document.querySelector(`[id*="${id}"],[data-id*="${id}"],[anim-data-id*="${id}"]`); if (!el) return;
      const leaf = [...el.querySelectorAll('*')].find(x => !x.children.length && (x.textContent || '').trim()); const name = ((leaf && leaf.textContent) || (el.innerText || '').split('\n')[0] || '').trim(); const img = el.querySelector('img');
      if (name && name.length < 80 && !/^\d+$/.test(name)) { if (GROUPS[id]) addGroup(id, name, img && img.src); else addUser(id, name, img && img.src); }
    } catch (e) {} });
  }
  async function send() {
    if (busy) return; const st = await new Promise(r => chrome.storage.local.get(['code', 'name'], r)); if (!st.code) return;
    const all = [...RAW.values()];
    if (!self && all.length && Date.now() - (window.__sktT0 || (window.__sktT0 = Date.now())) < 60000 && !all.some(m => m.__g)) return; // chờ biết nick của mình để phân loại đúng
    const msgs = all.map(m => { try { return norm(m); } catch (e) { return null; } }).filter(m => m && m.thread && m.thread !== '0' && m.thread !== self).slice(0, 400);
    const threads = {}, nameOf = id => (GROUPS[id] && GROUPS[id].name) || (USERS[id] && USERS[id].name) || '', avOf = id => (GROUPS[id] && GROUPS[id].avatar) || (USERS[id] && USERS[id].avatar) || '';
    msgs.forEach(m => SEEN.add(m.thread));
    msgs.forEach(m => { const t = threads[m.thread] || (threads[m.thread] = {id: m.thread, group: m.isGroup || !!GROUPS[m.thread], name: nameOf(m.thread), avatar: avOf(m.thread), lastTs: 0, lastText: ''});
      if (m.ts >= t.lastTs) { t.lastTs = m.ts; t.lastText = (m.me ? 'Bạn: ' : (t.group && m.fromName ? m.fromName + ': ' : '')) + (m.text || {photo: '[Hình ảnh]', sticker: '[Sticker]', voice: '[Tin nhắn thoại]', video: '[Video]', file: '[Tệp]'}[m.type] || '').slice(0, 150); } });
    // gửi kèm tên mới tìm được cho hội thoại cũ
    Object.keys(Object.assign({}, USERS, GROUPS)).forEach(id => { const nm = nameOf(id); if (nm && SENT_NAMES[id] !== nm && !threads[id]) threads[id] = {id, group: !!GROUPS[id], name: nm, avatar: avOf(id)}; });
    const tl = Object.values(threads).slice(0, 300);
    if (!msgs.length && !tl.length) return;
    busy = true;
    const meU = self && USERS[self];
    const acc = {uid: self || ('ma-' + st.code.slice(-10)), name: (meU && meU.name) || (st.name ? st.name + ' (Zalo)' : 'Zalo'), avatar: (meU && meU.avatar) || ''};
    const payload = {acc, threads: tl, msgs: msgs.map(m => ({thread: m.thread, id: m.id, ts: m.ts, me: m.me, fromName: m.fromName, type: m.type, text: m.text, url: m.url, file: m.file, styles: m.styles, threadName: nameOf(m.thread)}))};
    chrome.runtime.sendMessage({type: 'push', payload}, r => { if (r && r.ok) { msgs.forEach(m => RAW.delete(m.id)); tl.forEach(t => { if (t.name) SENT_NAMES[t.id] = t.name; }); } busy = false; });
  }
  setTimeout(() => scanIDB().catch(() => {}), 4000); setInterval(() => scanIDB().catch(() => {}), 10 * 60000);
  setInterval(() => scanDOM([...SEEN].filter(id => !USERS[id] && !GROUPS[id])), 30000);
  setInterval(send, 8000);
})();
