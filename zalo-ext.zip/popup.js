const API_DEFAULT = 'https://script.google.com/macros/s/AKfycbxRy87zV2uo1UzGSfc9HkL0OeF-euB-g0Z56h7uhpQ08UxQAaZqhRF3Cq2wgLKjnWIJ/exec';
const st = document.getElementById('st');
chrome.runtime.sendMessage({type: 'status'}, s => {
  s = s || {};
  if (!s.code) { st.textContent = 'Chưa kết nối. Vào CRM → Nhân sự → bấm "💬 Zalo" cạnh tên mình → Kết nối Zalo.'; return; }
  st.className = 'st ' + (s.err ? 'bad' : s.lastSync ? 'ok' : '');
  st.innerHTML = '<b>' + (s.name || '') + '</b> · nick: ' + (s.nick || 'chưa đọc được') + '<br>' + (s.err ? '⚠ ' + s.err : s.lastSync ? 'Đồng bộ lúc ' + new Date(s.lastSync).toLocaleTimeString('vi-VN') + ' · đã gửi ' + (s.sent || 0) + ' tin' : 'Mở chat.zalo.me và đăng nhập để bắt đầu.');
});
document.getElementById('save').onclick = () => {
  const c = document.getElementById('code').value.trim();
  if (!/^zl_[0-9a-f]{40}$/.test(c)) { st.className = 'st bad'; st.textContent = 'Mã không đúng dạng zl_…'; return; }
  chrome.storage.local.set({code: c, api: API_DEFAULT, err: ''}, () => { st.className = 'st ok'; st.textContent = 'Đã lưu mã. Mở / tải lại chat.zalo.me.'; });
};
