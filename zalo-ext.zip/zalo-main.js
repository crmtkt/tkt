// Chạy trong trang Zalo Web: bắt dữ liệu Zalo Web đã giải mã (tin nhắn, tên liên hệ, nhóm) khi trang tự đọc dữ liệu.
// Chỉ ĐỌC, không gửi gì cho Zalo, không bấm thay người dùng.
(() => {
  if (window.__sktZalo) return; window.__sktZalo = 1;
  const P = JSON.parse, out = {msgs: [], users: [], groups: [], self: null}; let n = 0, timer = 0;
  const flush = () => { timer = 0; if (!out.msgs.length && !out.users.length && !out.groups.length && !out.self) return;
    try { window.postMessage({src: 'skt-zmain', data: JSON.parse(JSON.stringify(out))}, location.origin); } catch (e) {}
    out.msgs = []; out.users = []; out.groups = []; out.self = null; };
  const later = () => { if (!timer) timer = setTimeout(flush, 1500); };
  const isMsg = o => o.msgId != null && o.uidFrom != null && o.ts != null && o.msgType != null;
  const walk = (o, d, g) => {
    if (!o || typeof o !== 'object' || d > 7 || n > 4000) return; n++;
    if (Array.isArray(o)) { for (let i = 0; i < o.length && i < 800; i++) walk(o[i], d + 1, g); return; }
    if (isMsg(o)) { const c = Object.assign({}, o); if (g) c.__g = 1; out.msgs.push(c); later(); return; }
    if (o.zpw_enk && o.uid) { out.self = {uid: String(o.uid)}; later(); }
    if (o.userId && (o.displayName || o.zaloName)) { out.users.push({id: String(o.userId), name: o.displayName || o.zaloName, avatar: o.avatar || ''}); later(); }
    if (o.groupId && o.name && (o.totalMember != null || o.avt != null || o.fullAvt != null)) { out.groups.push({id: String(o.groupId), name: o.name, avatar: o.fullAvt || o.avt || ''}); later(); }
    for (const k in o) { const v = o[k]; if (!v || typeof v !== 'object') continue;
      if (/gridInfoMap|groupInfo/i.test(k) && !Array.isArray(v)) for (const id in v) { const x = v[id]; if (x && x.name) { out.groups.push({id: String(x.groupId || id), name: x.name, avatar: x.fullAvt || x.avt || ''}); later(); } }
      if (/profiles?$/i.test(k) && !Array.isArray(v)) for (const id in v) { const x = v[id]; if (x && (x.displayName || x.zaloName)) { out.users.push({id: String(x.userId || id), name: x.displayName || x.zaloName, avatar: x.avatar || ''}); later(); } }
      walk(v, d + 1, g || /group/i.test(k)); }
  };
  JSON.parse = function (s, r) { const v = P.call(this, s, r); try { if (typeof s === 'string' && s.length > 40 && /msgId|userId|groupId|zpw_enk|gridInfoMap|profiles/.test(s)) { n = 0; walk(v, 0, false); } } catch (e) {} return v; };
})();
