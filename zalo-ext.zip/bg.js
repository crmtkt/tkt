// Lưu mã kết nối, gửi tin nhắn về CRM.
const get = k => new Promise(r => chrome.storage.local.get(k, r));
const set = o => new Promise(r => chrome.storage.local.set(o, r));
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (m.type === 'pair') {
    set({code: m.code, name: m.name, api: m.api, err: '', pairedAt: Date.now()}).then(async () => {
      const tabs = await chrome.tabs.query({url: 'https://chat.zalo.me/*'});
      if (tabs.length) { chrome.tabs.update(tabs[0].id, {active: true}); chrome.tabs.reload(tabs[0].id); }
      else chrome.tabs.create({url: 'https://chat.zalo.me/'});
      reply({ok: true});
    });
    return true;
  }
  if (m.type === 'push') {
    get(['code', 'api']).then(async c => {
      if (!c.code || !c.api) return reply({ok: false, error: 'Chưa có mã kết nối. Vào CRM → Nhân sự → Zalo → Kết nối Zalo.'});
      try {
        const res = await fetch(c.api + '?zalo=1', {method: 'POST', headers: {'Content-Type': 'text/plain;charset=utf-8'}, body: JSON.stringify(Object.assign({code: c.code}, m.payload))});
        const j = await res.json();
        const st = await get(['sent']);
        await set(j.ok ? {err: '', lastSync: Date.now(), nick: m.payload.acc && m.payload.acc.name, sent: (st.sent || 0) + (j.them || 0)} : {err: j.error || 'Lỗi'});
        reply(j);
      } catch (e) { await set({err: 'Không gửi được về CRM: ' + e.message}); reply({ok: false, error: e.message}); }
    });
    return true;
  }
  if (m.type === 'status') { get(null).then(s => reply(s)); return true; }
});
