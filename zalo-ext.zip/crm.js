// Cầu nối trang CRM <-> tiện ích: CRM bấm "Kết nối Zalo" sẽ gửi mã vào đây.
document.documentElement.setAttribute('data-skt-zalo', chrome.runtime.getManifest().version);
window.addEventListener('message', e => {
  const m = e.data; if (e.source !== window || !m || m.src !== 'skt-crm') return;
  if (m.type === 'pair' && /^zl_[0-9a-f]{40}$/.test(m.code || '') && /^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(m.api || '')) {
    chrome.runtime.sendMessage({type: 'pair', code: m.code, name: String(m.name || '').slice(0, 80), api: m.api}, r => window.postMessage({src: 'skt-ext', type: 'paired', ok: !!(r && r.ok)}, '*'));
  }
});
